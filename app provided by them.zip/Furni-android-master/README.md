# Furni-android
## Google Login 

<img height = "500" src = "/img/login1.jpeg">
<img height = "500" src = "/img/login2.jpeg">

## Dashboard
This contains the list of all the specific categories.

<img height = "500" src = "/img/dashboard.jpeg">

## Categories 

<img height = "500" src = "/img/categories.jpeg">

## List of requirements according to the category

<img height = "500" src = "/img/req.jpeg">

You can click on the items, to know more about them or to buy them.

<img height = "500" src = "/img/amz.jpeg">

## Navigation Bar 

<img height = "500" src = "/img/nav.jpeg">
